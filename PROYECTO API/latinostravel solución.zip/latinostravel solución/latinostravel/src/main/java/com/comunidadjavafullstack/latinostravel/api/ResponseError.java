package com.comunidadjavafullstack.latinostravel.api;

import java.util.Map;

public class ResponseError  extends Exception {
	private static final long serialVersionUID = 1L;
	private String messageError;
	private String codigoError;
	private Map<String, Object> mapa;
	private Object lista;
	
	public ResponseError()
	{
		super();
	}
	public ResponseError(String messageError) {
		super();
		this.messageError = messageError;
	}
	
	public ResponseError(String messageError, String codigoError) {
		super();
		this.messageError = messageError;
		this.codigoError = codigoError;
	}

	public ResponseError(String messageError, String codigoError, Map<String, Object> mapa) {
		super();
		this.messageError = messageError;
		this.codigoError = codigoError;
		this.mapa = mapa;
	}

	public ResponseError(String messageError, String codigoError, Object lista) {
		super();
		this.messageError = messageError;
		this.codigoError = codigoError;
		this.lista = lista;
	}
	
	public String getMessageError() {
		return messageError;
	}

	public void setMessageError(String messageError) {
		this.messageError = messageError;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}	
	
	public Object getLista() {
        return lista;
    }

    public void setLista(Object lista) {
        this.lista = lista;
    }

	public Map<String, Object> getMapa() {
		return mapa;
	}

	public void setMapa(Map<String, Object> mapa) {
		this.mapa = mapa;
	}
}
