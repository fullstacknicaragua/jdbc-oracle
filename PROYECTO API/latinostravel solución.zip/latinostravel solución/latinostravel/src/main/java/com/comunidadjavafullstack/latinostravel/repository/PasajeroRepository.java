package com.comunidadjavafullstack.latinostravel.repository;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.comunidadjavafullstack.latinostravel.dao.PasajeroDAO;
import com.comunidadjavafullstack.latinostravel.domain.Pasajero;
import com.comunidadjavafullstack.latinostravel.mapper.PasajeroMapper;
import com.comunidadjavafullstack.latinostravel.util.OracleJdbcCall;

import oracle.jdbc.OracleTypes;

@Repository
public class PasajeroRepository implements PasajeroDAO {

	public String schema = "SYSTEM";
	public String catalog = "PKG_LATINOSTRAVEL";
	
	private OracleJdbcCall<Pasajero> oracleJdbcCall;
	
	@Autowired
	public PasajeroRepository(JdbcTemplate jdbcTemplate) {
		oracleJdbcCall = new OracleJdbcCall<>(jdbcTemplate, schema, catalog);
	}
	
	public Map<String, Object> guardarPasajero(Pasajero pasajero)
	{
		return oracleJdbcCall.crearInstancia().newCall(CRUD_PASAJERO).addDeclareParametersIn(
				new int[] {
						OracleTypes.NUMBER,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.DATE,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR						
				},
					pPasajeroId, 
					pPrimerNombre, 
					pSegundoNombre,
					pPrimerApellido,
					pSegundoApellido,
					pTipoDocumento, 
					pNumDocumento,
					pFechaNacimiento,
					pPais,
					pTelefono,
					pEmail,
					pClave,
					pTipoOperacion
				).addParametersInValue(
						pasajero.getId(),
						pasajero.getPrimerNombre(),
						pasajero.getSegundoNombre(),
						pasajero.getPrimerApellido(),
						pasajero.getSegundoApellido(),
						pasajero.getTipoDocumento(),
						pasajero.getNumeroDocumento(),
						pasajero.getFechaNacimiento(),
						pasajero.getPais(),
						pasajero.getTelefono(),
						pasajero.getEmail(),
						pasajero.getClave(),
						"I"
						).addDeclareParametersOut(new int[] { OracleTypes.CURSOR, OracleTypes.VARCHAR, OracleTypes.VARCHAR}, new PasajeroMapper(), "pRegistro", "pResultado", "pMsgError")
				.execute();
				
	}
	
	public Map<String, Object> actualizarPasajero(Pasajero pasajero)
	{
		return oracleJdbcCall.crearInstancia().newCall(CRUD_PASAJERO).addDeclareParametersIn(
				new int[] {
						OracleTypes.NUMBER,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.DATE,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR,
						OracleTypes.VARCHAR						
				},
					pPasajeroId, 
					pPrimerNombre, 
					pSegundoNombre,
					pPrimerApellido,
					pSegundoApellido,
					pTipoDocumento, 
					pNumDocumento,
					pFechaNacimiento,
					pPais,
					pTelefono,
					pEmail,
					pClave,
					pTipoOperacion
				).addParametersInValue(
						pasajero.getId(),
						pasajero.getPrimerNombre(),
						pasajero.getSegundoNombre(),
						pasajero.getPrimerApellido(),
						pasajero.getSegundoApellido(),
						pasajero.getTipoDocumento(),
						pasajero.getNumeroDocumento(),
						pasajero.getFechaNacimiento(),
						pasajero.getPais(),
						pasajero.getTelefono(),
						pasajero.getEmail(),
						pasajero.getClave(),
						"U"
						).addDeclareParametersOut(new int[] { OracleTypes.CURSOR, OracleTypes.VARCHAR, OracleTypes.VARCHAR}, new PasajeroMapper(), "pRegistro", "pResultado", "pMsgError")
				.execute();
				
	}
}
