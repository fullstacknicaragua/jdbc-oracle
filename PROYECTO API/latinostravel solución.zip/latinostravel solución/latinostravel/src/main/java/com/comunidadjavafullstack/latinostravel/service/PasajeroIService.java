package com.comunidadjavafullstack.latinostravel.service;

import java.util.Map;

import com.comunidadjavafullstack.latinostravel.domain.Pasajero;

public interface PasajeroIService {
	
	Map<String, Object> guardarPasajero(Pasajero objeto);
	
	Map<String, Object> actualizarPasajero(Pasajero objeto);
}
