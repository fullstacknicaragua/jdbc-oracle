package com.comunidadjavafullstack.latinostravel.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import oracle.jdbc.OracleTypes;

public class OracleJdbcCall<T> {
	private JdbcTemplate jdbcTemplate;
	private SimpleJdbcCall simpleJdbcCall;

	private String schemaName;
	private String catalogName;

	private String[] declareParametersIn;
	private Map<String, Object> mapParametersInValue;
	
	public OracleJdbcCall<T> crearInstancia(){
	    var jdbcCall = new OracleJdbcCall<T>(new JdbcTemplate(jdbcTemplate.getDataSource()), schemaName, catalogName);
	    return jdbcCall;
	}

	public OracleJdbcCall(JdbcTemplate jdbcTemplate, String schemaName, String catalogName) {
		this.jdbcTemplate = jdbcTemplate;
		if (schemaName != null && !schemaName.trim().isEmpty() && catalogName != null
				&& !catalogName.trim().isEmpty()) {
			this.schemaName = schemaName;
			this.catalogName = catalogName;
			this.mapParametersInValue = new HashMap<>();
		} else {
			throw new NullPointerException("Los parámetros schemaName y catalogName no pueden ser null o vacío.");
		}
	}

	public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

	public OracleJdbcCall<T> newCall(String procedureName) {		
		if (procedureName != null && !procedureName.trim().isEmpty()) {			
			simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withSchemaName(schemaName).withCatalogName(catalogName)
					.withProcedureName(procedureName);
		} else {
			throw new NullPointerException("El parámetro procedureName no puede ser null o vacío.");
		}
		return this;
	}

	public OracleJdbcCall<T> addDeclareParametersIn(int[] paramOracleTypes, String... declareParametersIn) {
		if (simpleJdbcCall != null) {
			if (paramOracleTypes != null && declareParametersIn != null) {
				if (paramOracleTypes.length > 0 && declareParametersIn.length > 0) {
					if (paramOracleTypes.length == declareParametersIn.length) {
						this.declareParametersIn = declareParametersIn;
						for (int i = 0; i < declareParametersIn.length; i++) {
							if (declareParametersIn[i] != null && !declareParametersIn[i].trim().isEmpty()) {
								simpleJdbcCall.addDeclaredParameter(
										new SqlParameter(declareParametersIn[i], paramOracleTypes[i]));
							} else {
								throw new NullPointerException(
										"El parámetro declarado del Procedimiento no puede ser null o estar vacío.");
							}
						}
					} else {
						throw new ArrayIndexOutOfBoundsException(
								"La cantidad de argumentos en la variable paramOracleTypes difiere de la cantidad de "
										+ "argumentos definidos en la variable declareParametersIn, deben tener la misma cantidad "
										+ "de argumentos.");
					}
				} else {
					throw new NullPointerException(
							"Los parámetros paramOracleTypes y declareParametersIn deben contener al menos un valor ambos.");
				}
			} else {
				throw new NullPointerException(
						"Los parámetros paramOracleTypes y declareParametersIn no pueden ser null.");
			}
		} else {
			throw new NullPointerException(
					"Asegurese de invocar al metodo newCall antes de realizar cualquier operación, para poder crear una "
							+ "instancia del Objeto SimpleJdbcCall.");
		}
		return this;
	}

	public OracleJdbcCall<T> addParametersInValue(Object... parametersInValue) {
		if (parametersInValue != null) {
			if (parametersInValue.length > 0) {
				if (declareParametersIn != null && declareParametersIn.length > 0) {
					if (declareParametersIn.length == parametersInValue.length) {
						for (int i = 0; i < parametersInValue.length; i++) {
							mapParametersInValue.put(declareParametersIn[i], parametersInValue[i]);
						}
					} else {
						throw new ArrayIndexOutOfBoundsException(
								"La cantidad de argumentos en la variable declareParametersIn difiere de la cantidad de "
										+ "argumentos definidos en la variable parametersInValue, deben tener la misma cantida de argumentos.");
					}
				} else {
					throw new NullPointerException(
							"La variable declareParametersIn no puede ser null o estar vacío, antes de establecer los valores a "
									+ "los parámteros hay que declarar los parámetros.");
				}
			} else {
				throw new NullPointerException("La variable parametersInValue no puede estar vacío.");
			}
		} else {
			throw new NullPointerException("La variable parametersInValue no puede ser null.");
		}
		return this;
	}

	
	public OracleJdbcCall<T> addDeclareParametersOut(int[] paramOracleTypes, RowMapper<T> rowMapper,
			String... declareParametersOut) {
		if (simpleJdbcCall != null) {
			if (paramOracleTypes != null && declareParametersOut != null) {
				if (paramOracleTypes.length > 0 && declareParametersOut.length > 0) {
					if (paramOracleTypes.length == declareParametersOut.length) {
						for (int i = 0; i < declareParametersOut.length; i++) {
							if (declareParametersOut[i] != null && !declareParametersOut[i].trim().isEmpty()) {
								if (paramOracleTypes[i] == OracleTypes.CURSOR) {
									if (rowMapper != null) {
										simpleJdbcCall.addDeclaredParameter(
												new SqlOutParameter(declareParametersOut[i], paramOracleTypes[i], rowMapper));
									} else {
										throw new NullPointerException("La implementación de RowMapper no puede ser null.");
									}
								} else {
									simpleJdbcCall.addDeclaredParameter(
											new SqlOutParameter(declareParametersOut[i], paramOracleTypes[i]));
								}
							} else {
								throw new NullPointerException(
										"El parámetro declarado del Procedimiento no puede ser null o estar vacío.");
							}
						}
					} else {
						throw new ArrayIndexOutOfBoundsException(
								"La cantidad de argumentos en la variable paramOracleTypes difiere de la cantidad de "
										+ "argumentos definidos en la variable declareParametersOut, deben tener la misma cantida "
										+ "de argumentos.");
					}
				} else {
					throw new NullPointerException("Los parámetros paramOracleTypes y declareParametersOut deben contener al menos un valor ambos.");
				}
			} else {
				throw new NullPointerException("Los parámetros paramOracleTypes y declareParametersOut no pueden ser null.");
			}
		} else {
			throw new NullPointerException(
					"No se ha invocado al metodo newCall para crear" + " una instancia del Objeto SimpleJdbcCall.");
		}
		return this;
	}
		
	public Map<String, Object> execute(Map<String, Object> mapParametersInValue) {
		return simpleJdbcCall.execute(mapParametersInValue);
	}

	public Map<String, Object> execute() {
		return simpleJdbcCall.execute(mapParametersInValue);
	}
}