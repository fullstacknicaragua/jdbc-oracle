package com.comunidadjavafullstack.latinostravel.domain;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class Pasajero {
	@ApiModelProperty(position = 0)
	private Long id;
	@ApiModelProperty(position = 1)
	private String primerNombre;
	@ApiModelProperty(position = 2)
	private String segundoNombre;
	@ApiModelProperty(position = 3)
	private String primerApellido;
	@ApiModelProperty(position = 4)
	private String segundoApellido;
	@ApiModelProperty(position = 5)
	private String tipoDocumento;
	@ApiModelProperty(position = 6)
	private String numeroDocumento;
	@ApiModelProperty(position = 7)
	private LocalDate fechaNacimiento;
	@ApiModelProperty(position = 8)
	private String pais;
	@ApiModelProperty(position = 9)
	private String telefono;
	@ApiModelProperty(position = 10)
	private String email;
	@ApiModelProperty(position = 11)
	private String clave;
	
	
}
