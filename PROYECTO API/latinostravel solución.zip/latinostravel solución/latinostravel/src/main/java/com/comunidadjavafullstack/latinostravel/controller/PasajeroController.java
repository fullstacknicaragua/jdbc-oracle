package com.comunidadjavafullstack.latinostravel.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.comunidadjavafullstack.latinostravel.api.ResponseMessage;
import com.comunidadjavafullstack.latinostravel.domain.Pasajero;
import com.comunidadjavafullstack.latinostravel.service.PasajeroIService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins ="*")
@Api(description = "Este controlador va a manejar la insercion y actualizacion de registros de Pasajeros")
@RestController
@RequestMapping("${api.version}/${api.base}/gestion")
public class PasajeroController {
	
	private PasajeroIService pasajeroIService;
	
	@Autowired
	public PasajeroController(PasajeroIService pasajeroIService) {
		this.pasajeroIService = pasajeroIService;
	}
	
	@ApiOperation(value="Crear Pasajero", notes="Este servicio se utiliza para crear un registro de Pasajero")
	@PostMapping("pasajero")
	public ResponseEntity<ResponseMessage> guardarPasajero(@RequestBody Pasajero objeto) {
		Map<String, Object> map = pasajeroIService.guardarPasajero(objeto);
		var lista = Optional.<List<?>>ofNullable((ArrayList<?>) map.get("pRegistro"));
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setStatus(HttpStatus.OK.value());
		responseMessage.setError((map.get("pMsgError") != null) ? map.get("pMsgError").toString() : null);
		responseMessage.setMessage((map.get("pResultado") != null) ? map.get("pResultado").toString() : null);
		responseMessage.setData(lista.orElse(null));
		return new ResponseEntity<>(responseMessage, HttpStatus.OK);
		
	}
	
	@ApiOperation(value="Actualizar Pasajero", notes="Este servicio se utiliza para actualizar un registro de Pasajero")
	@PutMapping("pasajero")
	public ResponseEntity<ResponseMessage> actualizarPasajero(@RequestBody Pasajero objeto) {
		Map<String, Object> map = pasajeroIService.actualizarPasajero(objeto);
		var lista = Optional.<List<?>>ofNullable((ArrayList<?>) map.get("pRegistro"));
		ResponseMessage responseMessage = new ResponseMessage();
		responseMessage.setStatus(HttpStatus.OK.value());
		responseMessage.setError((map.get("pMsgError") != null) ? map.get("pMsgError").toString() : null);
		responseMessage.setMessage((map.get("pResultado") != null) ? map.get("pResultado").toString() : null);
		responseMessage.setData(lista.orElse(null));
		return new ResponseEntity<>(responseMessage, HttpStatus.OK);
		
	}
}
