package com.comunidadjavafullstack.latinostravel.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.comunidadjavafullstack.latinostravel.dao.PasajeroDAO;
import com.comunidadjavafullstack.latinostravel.domain.Pasajero;

@Transactional
@Service
public class PasajeroImpIService implements PasajeroIService {
	
	private PasajeroDAO pasajeroDAO;
	
	@Autowired
	public PasajeroImpIService(PasajeroDAO pasajeroDAO) {
		this.pasajeroDAO = pasajeroDAO;
	}
	
	@Transactional
	@Override
	public Map<String, Object> guardarPasajero(Pasajero objeto){
		return pasajeroDAO.guardarPasajero(objeto);
	}
	
	@Transactional
	@Override
	public Map<String, Object> actualizarPasajero(Pasajero objeto){
		return pasajeroDAO.actualizarPasajero(objeto);
	}
}
