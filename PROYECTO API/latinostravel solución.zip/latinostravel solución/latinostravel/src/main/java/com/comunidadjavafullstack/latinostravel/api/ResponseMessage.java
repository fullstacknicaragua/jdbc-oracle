package com.comunidadjavafullstack.latinostravel.api;

import lombok.Data;

@Data
public class ResponseMessage {
	
	private int status;
	private String error;
	private String message;
	private Object data;
	
}
